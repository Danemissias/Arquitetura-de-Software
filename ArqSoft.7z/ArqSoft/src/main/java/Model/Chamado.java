package Model;

public class Chamado {

}
