package Model;

public class Fila {

}
