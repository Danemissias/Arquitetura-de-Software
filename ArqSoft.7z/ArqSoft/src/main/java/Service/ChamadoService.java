package Service;

public class ChamadoService {

}
